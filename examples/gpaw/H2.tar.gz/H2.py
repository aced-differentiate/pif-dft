from gpaw import GPAW
from ase.build import molecule

a = 10.

atom = molecule('H2')
atom.set_cell([a,a,a])
atom.center()

#Define Calculator
calc = GPAW(xc='BEEF-vdW',
            h=0.18, 
            txt="H2.txt",
            occupations = {'name':'fermi-dirac','width':0.05})

atom.calc = calc

atom.get_potential_energy()

atom.write("H2.traj")
